#!/usr/bin/env python
# coding: utf-8

# # TIME-SERIES FORECASTING IN STOCKS FROM(2000 TO 2021)

# In[1]:


pip install yfinance  


# In[2]:


import pandas as pd
import numpy as np
import yfinance as yf
import datetime
from datetime import date, timedelta


# In[3]:


import datetime
import matplotlib.pyplot as plt
from pandas.plotting import scatter_matrix
get_ipython().run_line_magic('matplotlib', 'inline')


# In[4]:


import plotly.graph_objects as go
import plotly.express as px


# In[5]:


dD = pd.read_csv(r"C:\\Users\\ANESTHESIA\\Downloads\\stock_prices.csv")
dD.head()


# In[6]:


dD.isnull().sum()


# In[7]:


dD.info()


# In[8]:


start = "2014-01-01"
end = '2019-1-01'
tcs = yf.download('TCS',start,end)
wipro = yf.download('WIPRO.NS',start,end)


# In[9]:


tcs['MarktCap'] = tcs['Open'] * tcs['Volume']
wipro['MarktCap'] = wipro['Open'] * wipro['Volume']
tcs['MarktCap'].plot(label = 'TCS', figsize = (15,8))
wipro['MarktCap'].plot(label = 'Wipro')
plt.legend()


# In[ ]:





# In[10]:


tcs['MA50'] = tcs['Open'].rolling(50).mean()
tcs['MA200'] = tcs['Open'].rolling(200).mean()
tcs['Open'].plot(figsize = (15,7))
tcs['MA50'].plot()
tcs['MA200'].plot()


# In[11]:


plt.figure(figsize=(16, 8)) 
cols = ['Open', 'Close', 'Volume', 'High', 'Low']
axes = dD[cols].plot(figsize=(11, 9), subplots = True)
plt.show()


# In[12]:


dD.describe()


# In[13]:


dD.isnull().sum()


# In[14]:


plt.figure(figsize=(18, 8))
dD['Adj Close'].plot()
plt.legend(loc=4)
plt.xlabel('Date')
plt.ylabel('Price')
plt.show()


# In[15]:


from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt


# In[16]:


data = pd.read_csv(r"C:\\Users\\ANESTHESIA\\Downloads\\stock_prices.csv")  
data.head()


# In[17]:


from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from tensorflow.keras.callbacks import EarlyStopping


# In[18]:


data = data[['Close']]
dataset = data.values


# In[19]:


scaler = MinMaxScaler(feature_range=(0, 1))
dataset = scaler.fit_transform(dataset)


# In[20]:


def create_sequences(dataset, look_back=1):
    X, Y = [], []
    for i in range(len(dataset) - look_back):
        X.append(dataset[i:(i + look_back), 0])
        Y.append(dataset[i + look_back, 0])
    return np.array(X), np.array(Y)

look_back = 10  
X, Y = create_sequences(dataset, look_back)


# In[21]:


X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=0)


# In[22]:


model = Sequential()
model.add(LSTM(50, input_shape=(look_back, 1)))
model.add(Dense(1))
model.compile(loss='mean_squared_error', optimizer='adam')


# In[23]:


early_stopping = EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)
model.fit(X_train, y_train, epochs=50, batch_size=64, validation_data=(X_test, y_test), callbacks=[early_stopping])


# In[24]:


train_predict = model.predict(X_train)
test_predict = model.predict(X_test)


# In[25]:


train_predict = scaler.inverse_transform(train_predict)
test_predict = scaler.inverse_transform(test_predict)


# In[26]:


plt.figure(figsize=(12, 6))
plt.plot(data.index[look_back:len(train_predict) + look_back], train_predict, label='Training Predictions', color='blue')


# In[27]:


plt.plot(data.index, data['Close'], label='Actual Close Prices', color='green')
plt.xlabel('Time')
plt.ylabel('Close Price')
plt.title('Stock Price Prediction Using Deep Learning (LSTM)')
plt.legend()
plt.show()


# In[28]:


from sklearn.metrics import mean_squared_error
train_mse = mean_squared_error(y_train, train_predict)
test_mse = mean_squared_error(y_test, test_predict)
print(f"Training MSE: {train_mse}")
print(f"Testing MSE: {test_mse}")


# In[ ]:




